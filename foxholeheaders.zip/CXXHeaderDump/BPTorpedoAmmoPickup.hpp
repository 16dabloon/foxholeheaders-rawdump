#ifndef UE4SS_SDK_BPTorpedoAmmoPickup_HPP
#define UE4SS_SDK_BPTorpedoAmmoPickup_HPP

class ABPTorpedoAmmoPickup_C : public AAmmoPickup
{
    class USkeletalMeshComponent* ItemMeshSK;                                         // 0x0430 (size: 0x8)

}; // Size: 0x438

#endif
