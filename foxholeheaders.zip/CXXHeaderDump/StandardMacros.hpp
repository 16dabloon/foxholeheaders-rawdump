#ifndef UE4SS_SDK_StandardMacros_HPP
#define UE4SS_SDK_StandardMacros_HPP

class UStandardMacros_C : public UObject
{
}; // Size: 0x28

#endif
