#ifndef UE4SS_SDK_BPTrainDriverMountComponent_HPP
#define UE4SS_SDK_BPTrainDriverMountComponent_HPP

class UBPTrainDriverMountComponent_C : public UTrainPassengerMountComponent
{
}; // Size: 0x868

#endif
