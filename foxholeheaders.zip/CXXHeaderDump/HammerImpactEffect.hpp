#ifndef UE4SS_SDK_HammerImpactEffect_HPP
#define UE4SS_SDK_HammerImpactEffect_HPP

class AHammerImpactEffect_C : public AImpactEffect
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0280 (size: 0x8)

}; // Size: 0x288

#endif
