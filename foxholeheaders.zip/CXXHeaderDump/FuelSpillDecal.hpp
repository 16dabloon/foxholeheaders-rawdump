#ifndef UE4SS_SDK_FuelSpillDecal_HPP
#define UE4SS_SDK_FuelSpillDecal_HPP

class AFuelSpillDecal_C : public ADecalActor
{
}; // Size: 0x220

#endif
