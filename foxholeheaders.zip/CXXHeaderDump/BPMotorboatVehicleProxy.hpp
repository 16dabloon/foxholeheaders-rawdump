#ifndef UE4SS_SDK_BPMotorboatVehicleProxy_HPP
#define UE4SS_SDK_BPMotorboatVehicleProxy_HPP

class ABPMotorboatVehicleProxy_C : public ABuildableStructure
{
}; // Size: 0x820

#endif
