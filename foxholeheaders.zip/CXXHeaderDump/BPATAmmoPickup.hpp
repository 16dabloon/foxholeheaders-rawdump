#ifndef UE4SS_SDK_BPATAmmoPickup_HPP
#define UE4SS_SDK_BPATAmmoPickup_HPP

class ABPATAmmoPickup_C : public ATankAmmoPickup
{
}; // Size: 0x450

#endif
