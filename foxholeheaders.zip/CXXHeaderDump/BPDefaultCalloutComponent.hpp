#ifndef UE4SS_SDK_BPDefaultCalloutComponent_HPP
#define UE4SS_SDK_BPDefaultCalloutComponent_HPP

class UBPDefaultCalloutComponent_C : public UCalloutComponent
{
}; // Size: 0xD8

#endif
