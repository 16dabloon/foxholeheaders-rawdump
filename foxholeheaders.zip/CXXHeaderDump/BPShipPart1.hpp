#ifndef UE4SS_SDK_BPShipPart1_HPP
#define UE4SS_SDK_BPShipPart1_HPP

class ABPShipPart1_C : public ABPShipPartBase_C
{
    class UMultiplexedStaticMeshComponent* MultiplexedMainMesh;                       // 0x0848 (size: 0x8)

}; // Size: 0x850

#endif
