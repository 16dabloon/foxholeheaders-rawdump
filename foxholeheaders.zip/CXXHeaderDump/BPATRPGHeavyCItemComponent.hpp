#ifndef UE4SS_SDK_BPATRPGHeavyCItemComponent_HPP
#define UE4SS_SDK_BPATRPGHeavyCItemComponent_HPP

class UBPATRPGHeavyCItemComponent_C : public UBPATRPGCItemComponent_C
{
}; // Size: 0x980

#endif
