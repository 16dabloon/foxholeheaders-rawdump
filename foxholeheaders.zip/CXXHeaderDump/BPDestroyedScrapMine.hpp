#ifndef UE4SS_SDK_BPDestroyedScrapMine_HPP
#define UE4SS_SDK_BPDestroyedScrapMine_HPP

class ABPDestroyedScrapMine_C : public ADestroyedResourceMine
{
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0628 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0630 (size: 0x8)
    class UBoxComponent* NoBuildArea;                                                 // 0x0638 (size: 0x8)
    class UDecalComponent* Decal;                                                     // 0x0640 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0648 (size: 0x8)

}; // Size: 0x650

#endif
