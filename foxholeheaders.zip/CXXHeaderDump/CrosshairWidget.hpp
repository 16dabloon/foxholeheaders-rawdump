#ifndef UE4SS_SDK_CrosshairWidget_HPP
#define UE4SS_SDK_CrosshairWidget_HPP

class UCrosshairWidget_C : public UCursorWidget
{
    class UImage* Image_117;                                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
