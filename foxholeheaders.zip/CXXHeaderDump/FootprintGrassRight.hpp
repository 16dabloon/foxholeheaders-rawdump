#ifndef UE4SS_SDK_FootprintGrassRight_HPP
#define UE4SS_SDK_FootprintGrassRight_HPP

class AFootprintGrassRight_C : public ADecalActor
{
}; // Size: 0x220

#endif
