#ifndef UE4SS_SDK_BPLineOfSightVisualizationActor_HPP
#define UE4SS_SDK_BPLineOfSightVisualizationActor_HPP

class ABPLineOfSightVisualizationActor_C : public ALineOfSightVisualizationActor
{
}; // Size: 0x350

#endif
