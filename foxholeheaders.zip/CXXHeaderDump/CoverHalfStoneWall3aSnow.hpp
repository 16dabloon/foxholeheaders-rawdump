#ifndef UE4SS_SDK_CoverHalfStoneWall3aSnow_HPP
#define UE4SS_SDK_CoverHalfStoneWall3aSnow_HPP

class ACoverHalfStoneWall3aSnow_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0218 (size: 0x8)
    class UStaticMeshComponent* CoverHalfStoneWall3;                                  // 0x0220 (size: 0x8)
    class UStaticMeshComponent* PillarStoneWall3;                                     // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
