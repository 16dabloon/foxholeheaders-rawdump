#ifndef UE4SS_SDK_BPFortCornerCommonT2T3Mods_HPP
#define UE4SS_SDK_BPFortCornerCommonT2T3Mods_HPP

class ABPFortCornerCommonT2T3Mods_C : public ATemplate
{
    class UBPFortStairsModSlot_C* AngleFortStairsModSlot;                             // 0x0218 (size: 0x8)
    class UBPFortStairsModSlot_C* LeftFortStairsModSlot;                              // 0x0220 (size: 0x8)
    class UBPFortStairsModSlot_C* BackFortStairsModSlot;                              // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
