#ifndef UE4SS_SDK_BPHeavyKineticDamageType_HPP
#define UE4SS_SDK_BPHeavyKineticDamageType_HPP

class UBPHeavyKineticDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
