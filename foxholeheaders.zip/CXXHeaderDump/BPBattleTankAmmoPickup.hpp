#ifndef UE4SS_SDK_BPBattleTankAmmoPickup_HPP
#define UE4SS_SDK_BPBattleTankAmmoPickup_HPP

class ABPBattleTankAmmoPickup_C : public ATankAmmoPickup
{
    class USkeletalMeshComponent* ItemMeshSK;                                         // 0x0450 (size: 0x8)

}; // Size: 0x458

#endif
