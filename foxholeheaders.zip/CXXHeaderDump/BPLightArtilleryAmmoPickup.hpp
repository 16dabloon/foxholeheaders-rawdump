#ifndef UE4SS_SDK_BPLightArtilleryAmmoPickup_HPP
#define UE4SS_SDK_BPLightArtilleryAmmoPickup_HPP

class ABPLightArtilleryAmmoPickup_C : public AExplosiveAmmoPickup
{
    class USkeletalMeshComponent* ItemMeshSK;                                         // 0x0450 (size: 0x8)

}; // Size: 0x458

#endif
