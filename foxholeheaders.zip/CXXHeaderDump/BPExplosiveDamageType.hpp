#ifndef UE4SS_SDK_BPExplosiveDamageType_HPP
#define UE4SS_SDK_BPExplosiveDamageType_HPP

class UBPExplosiveDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
