#ifndef UE4SS_SDK_RiverSplashes7_HPP
#define UE4SS_SDK_RiverSplashes7_HPP

class ARiverSplashes7_C : public AEnvironmentVFX
{
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0228 (size: 0x8)

}; // Size: 0x230

#endif
