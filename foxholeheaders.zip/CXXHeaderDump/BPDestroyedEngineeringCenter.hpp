#ifndef UE4SS_SDK_BPDestroyedEngineeringCenter_HPP
#define UE4SS_SDK_BPDestroyedEngineeringCenter_HPP

class ABPDestroyedEngineeringCenter_C : public ADestroyedSpecializedFactory
{
    class UDecalComponent* Decal;                                                     // 0x0640 (size: 0x8)
    class UStaticMeshComponent* EngineeringCenter;                                    // 0x0648 (size: 0x8)

}; // Size: 0x650

#endif
