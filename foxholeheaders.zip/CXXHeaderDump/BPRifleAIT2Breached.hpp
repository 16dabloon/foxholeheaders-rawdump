#ifndef UE4SS_SDK_BPRifleAIT2Breached_HPP
#define UE4SS_SDK_BPRifleAIT2Breached_HPP

class ABPRifleAIT2Breached_C : public ADestroyedFort
{
    class UTemplateComponent* FortDestroyedT2Meshes;                                  // 0x0850 (size: 0x8)
    class ULocationMultiplexedMeshComponent* LocationMultiplexedMesh;                 // 0x0858 (size: 0x8)
    class UTemplateComponent* FortCommonDirtT1T2;                                     // 0x0860 (size: 0x8)
    class UTemplateComponent* FortBreachedCommon;                                     // 0x0868 (size: 0x8)
    class UStaticMeshComponent* Floor;                                                // 0x0870 (size: 0x8)

}; // Size: 0x878

#endif
