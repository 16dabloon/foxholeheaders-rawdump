#ifndef UE4SS_SDK_FootprintRoadRight_HPP
#define UE4SS_SDK_FootprintRoadRight_HPP

class AFootprintRoadRight_C : public ADecalActor
{
}; // Size: 0x220

#endif
