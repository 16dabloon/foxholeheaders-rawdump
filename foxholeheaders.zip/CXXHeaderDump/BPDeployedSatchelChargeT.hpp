#ifndef UE4SS_SDK_BPDeployedSatchelChargeT_HPP
#define UE4SS_SDK_BPDeployedSatchelChargeT_HPP

class ABPDeployedSatchelChargeT_C : public ADeployedWeapon
{
    class UExplodeOnDeathComponent* ExplodeOnDeath;                                   // 0x0890 (size: 0x8)
    class UBoxComponent* CollisionBox;                                                // 0x0898 (size: 0x8)

}; // Size: 0x8A0

#endif
