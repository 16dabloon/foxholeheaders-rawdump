#ifndef UE4SS_SDK_BPBadWordFilter_HPP
#define UE4SS_SDK_BPBadWordFilter_HPP

class UBPBadWordFilter_C : public UBadWordFilter
{
}; // Size: 0x48

#endif
