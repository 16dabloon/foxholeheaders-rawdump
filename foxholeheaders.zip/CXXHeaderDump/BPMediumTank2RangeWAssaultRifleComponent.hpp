#ifndef UE4SS_SDK_BPMediumTank2RangeWAssaultRifleComponent_HPP
#define UE4SS_SDK_BPMediumTank2RangeWAssaultRifleComponent_HPP

class UBPMediumTank2RangeWAssaultRifleComponent_C : public UHitScanMountComponent
{
}; // Size: 0x928

#endif
