#ifndef UE4SS_SDK_BPATRPGWPickup_HPP
#define UE4SS_SDK_BPATRPGWPickup_HPP

class ABPATRPGWPickup_C : public AItemPickup
{
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x03F0 (size: 0x8)

}; // Size: 0x3F8

#endif
