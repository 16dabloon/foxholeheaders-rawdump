#ifndef UE4SS_SDK_BPFlameBackpackW_HPP
#define UE4SS_SDK_BPFlameBackpackW_HPP

class UBPFlameBackpackW_C : public UAmmoBackpackItemComponent
{
}; // Size: 0x8F8

#endif
