#ifndef UE4SS_SDK_TractorBP2_HPP
#define UE4SS_SDK_TractorBP2_HPP

class ATractorBP2_C : public AActor
{
    class UStaticMeshComponent* Tractorv1;                                            // 0x0218 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
