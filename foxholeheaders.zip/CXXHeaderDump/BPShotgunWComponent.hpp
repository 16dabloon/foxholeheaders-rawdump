#ifndef UE4SS_SDK_BPShotgunWComponent_HPP
#define UE4SS_SDK_BPShotgunWComponent_HPP

class UBPShotgunWComponent_C : public UBPShotgunComponent_C
{
}; // Size: 0x9D0

#endif
