#ifndef UE4SS_SDK_BPFieldCannonWGunner_HPP
#define UE4SS_SDK_BPFieldCannonWGunner_HPP

class UBPFieldCannonWGunner_C : public UTankGunnerMountComponent
{
}; // Size: 0x8E0

#endif
