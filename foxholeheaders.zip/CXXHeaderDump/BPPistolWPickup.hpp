#ifndef UE4SS_SDK_BPPistolWPickup_HPP
#define UE4SS_SDK_BPPistolWPickup_HPP

class ABPPistolWPickup_C : public AFirearmPickup
{
}; // Size: 0x3F0

#endif
