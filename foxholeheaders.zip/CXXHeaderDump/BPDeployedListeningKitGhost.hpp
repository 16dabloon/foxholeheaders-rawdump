#ifndef UE4SS_SDK_BPDeployedListeningKitGhost_HPP
#define UE4SS_SDK_BPDeployedListeningKitGhost_HPP

class ABPDeployedListeningKitGhost_C : public ABuildGhost
{
    class UBuildSocketComponent* BuildSocket;                                         // 0x0580 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh1;                                      // 0x0588 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0590 (size: 0x8)

}; // Size: 0x598

#endif
