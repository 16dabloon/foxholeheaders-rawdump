#ifndef UE4SS_SDK_BPGroundMaterialsPickup_HPP
#define UE4SS_SDK_BPGroundMaterialsPickup_HPP

class ABPGroundMaterialsPickup_C : public ABasicItemPickup
{
}; // Size: 0x3F0

#endif
