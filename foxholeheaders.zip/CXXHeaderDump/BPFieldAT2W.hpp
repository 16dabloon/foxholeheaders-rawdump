#ifndef UE4SS_SDK_BPFieldAT2W_HPP
#define UE4SS_SDK_BPFieldAT2W_HPP

class ABPFieldAT2W_C : public ABPFieldGunBase_C
{
}; // Size: 0x1320

#endif
