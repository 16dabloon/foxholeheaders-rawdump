#ifndef UE4SS_SDK_FootprintSandRight_HPP
#define UE4SS_SDK_FootprintSandRight_HPP

class AFootprintSandRight_C : public ADecalActor
{
}; // Size: 0x220

#endif
