#ifndef UE4SS_SDK_BPDeployedRPGTWGhost_HPP
#define UE4SS_SDK_BPDeployedRPGTWGhost_HPP

class ABPDeployedRPGTWGhost_C : public ABuildGhost
{
    class UBuildSocketComponent* BuildSocket;                                         // 0x0580 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh1;                                      // 0x0588 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0590 (size: 0x8)
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0598 (size: 0x8)

}; // Size: 0x5A0

#endif
