#ifndef UE4SS_SDK_BPATGrenadeW_HPP
#define UE4SS_SDK_BPATGrenadeW_HPP

class ABPATGrenadeW_C : public AWarProjectile
{
    class UStaticMeshComponent* GrenadeMesh;                                          // 0x0328 (size: 0x8)

}; // Size: 0x330

#endif
