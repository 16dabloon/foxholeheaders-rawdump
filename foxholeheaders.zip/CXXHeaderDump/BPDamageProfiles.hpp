#ifndef UE4SS_SDK_BPDamageProfiles_HPP
#define UE4SS_SDK_BPDamageProfiles_HPP

class ABPDamageProfiles_C : public ADamageProfiles
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x08C8 (size: 0x8)

}; // Size: 0x8D0

#endif
