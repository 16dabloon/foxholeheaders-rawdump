#ifndef UE4SS_SDK_FootprintSandLeft_HPP
#define UE4SS_SDK_FootprintSandLeft_HPP

class AFootprintSandLeft_C : public ADecalActor
{
}; // Size: 0x220

#endif
