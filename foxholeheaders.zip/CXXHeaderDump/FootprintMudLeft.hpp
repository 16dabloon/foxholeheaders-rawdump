#ifndef UE4SS_SDK_FootprintMudLeft_HPP
#define UE4SS_SDK_FootprintMudLeft_HPP

class AFootprintMudLeft_C : public ADecalActor
{
}; // Size: 0x220

#endif
