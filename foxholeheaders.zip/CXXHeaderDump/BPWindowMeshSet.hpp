#ifndef UE4SS_SDK_BPWindowMeshSet_HPP
#define UE4SS_SDK_BPWindowMeshSet_HPP

class UBPWindowMeshSet_C : public UWindowMeshSet
{
}; // Size: 0xB8

#endif
