#ifndef UE4SS_SDK_In06k_HPP
#define UE4SS_SDK_In06k_HPP

class AIn06k_C : public ALorePickup
{
}; // Size: 0x3F8

#endif
