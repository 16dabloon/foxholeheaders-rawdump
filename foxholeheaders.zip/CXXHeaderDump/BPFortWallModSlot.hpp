#ifndef UE4SS_SDK_BPFortWallModSlot_HPP
#define UE4SS_SDK_BPFortWallModSlot_HPP

class UBPFortWallModSlot_C : public UModificationSlotComponent
{
}; // Size: 0x430

#endif
