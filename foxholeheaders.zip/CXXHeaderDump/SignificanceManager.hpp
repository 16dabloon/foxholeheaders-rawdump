#ifndef UE4SS_SDK_SignificanceManager_HPP
#define UE4SS_SDK_SignificanceManager_HPP

class USignificanceManager : public UObject
{
    FSoftClassPath SignificanceManagerClassName;                                      // 0x0100 (size: 0x18)

}; // Size: 0x118

#endif
