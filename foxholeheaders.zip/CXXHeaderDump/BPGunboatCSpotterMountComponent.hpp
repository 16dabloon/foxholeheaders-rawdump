#ifndef UE4SS_SDK_BPGunboatCSpotterMountComponent_HPP
#define UE4SS_SDK_BPGunboatCSpotterMountComponent_HPP

class UBPGunboatCSpotterMountComponent_C : public USpotterMountComponent
{
}; // Size: 0x870

#endif
