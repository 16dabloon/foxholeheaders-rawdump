#ifndef UE4SS_SDK_BPExplosivePickup_HPP
#define UE4SS_SDK_BPExplosivePickup_HPP

class ABPExplosivePickup_C : public ABasicItemPickup
{
}; // Size: 0x3F0

#endif
