#ifndef UE4SS_SDK_BPATRifleLightCPickup_HPP
#define UE4SS_SDK_BPATRifleLightCPickup_HPP

class ABPATRifleLightCPickup_C : public AFirearmPickup
{
}; // Size: 0x3F0

#endif
