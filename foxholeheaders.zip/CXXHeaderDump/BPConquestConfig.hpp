#ifndef UE4SS_SDK_BPConquestConfig_HPP
#define UE4SS_SDK_BPConquestConfig_HPP

class ABPConquestConfig_C : public AConquestConfig
{
}; // Size: 0x238

#endif
