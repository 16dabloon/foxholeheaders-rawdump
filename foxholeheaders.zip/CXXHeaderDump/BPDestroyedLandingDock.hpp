#ifndef UE4SS_SDK_BPDestroyedLandingDock_HPP
#define UE4SS_SDK_BPDestroyedLandingDock_HPP

class ABPDestroyedLandingDock_C : public ADestroyedStructure
{
    class UBoxComponent* Box;                                                         // 0x0620 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0628 (size: 0x8)

}; // Size: 0x630

#endif
