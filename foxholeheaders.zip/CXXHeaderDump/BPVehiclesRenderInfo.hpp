#ifndef UE4SS_SDK_BPVehiclesRenderInfo_HPP
#define UE4SS_SDK_BPVehiclesRenderInfo_HPP

class ABPVehiclesRenderInfo_C : public AVehiclesRenderInfo
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0238 (size: 0x8)

}; // Size: 0x240

#endif
