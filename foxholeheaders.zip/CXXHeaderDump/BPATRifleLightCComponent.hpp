#ifndef UE4SS_SDK_BPATRifleLightCComponent_HPP
#define UE4SS_SDK_BPATRifleLightCComponent_HPP

class UBPATRifleLightCComponent_C : public UATRifleComponent
{
}; // Size: 0x9C0

#endif
