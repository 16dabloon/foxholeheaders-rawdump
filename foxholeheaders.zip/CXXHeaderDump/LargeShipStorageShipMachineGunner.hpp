#ifndef UE4SS_SDK_LargeShipStorageShipMachineGunner_HPP
#define UE4SS_SDK_LargeShipStorageShipMachineGunner_HPP

class ULargeShipStorageShipMachineGunner_C : public UBPColVehicleMachineGunnerComponent_C
{
}; // Size: 0x928

#endif
