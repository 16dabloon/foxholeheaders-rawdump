#ifndef UE4SS_SDK_BPFoliageCullingRVTVolume_HPP
#define UE4SS_SDK_BPFoliageCullingRVTVolume_HPP

class ABPFoliageCullingRVTVolume_C : public ARuntimeVirtualTextureVolume
{
}; // Size: 0x220

#endif
