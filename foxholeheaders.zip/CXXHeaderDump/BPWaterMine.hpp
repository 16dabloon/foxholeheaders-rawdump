#ifndef UE4SS_SDK_BPWaterMine_HPP
#define UE4SS_SDK_BPWaterMine_HPP

class ABPWaterMine_C : public AWaterMine
{
}; // Size: 0x318

#endif
