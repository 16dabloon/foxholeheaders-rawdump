#ifndef UE4SS_SDK_BPTruckMobilityW_HPP
#define UE4SS_SDK_BPTruckMobilityW_HPP

class ABPTruckMobilityW_C : public ABPTruckBaseW_C
{
    class UTowHitchUseComponent* TowHitchUse;                                         // 0x13F8 (size: 0x8)

}; // Size: 0x1400

#endif
