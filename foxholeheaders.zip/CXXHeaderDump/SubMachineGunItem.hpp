#ifndef UE4SS_SDK_SubMachineGunItem_HPP
#define UE4SS_SDK_SubMachineGunItem_HPP

class USubMachineGunItem_C : public UHeavyMachineGunItemComponent
{
}; // Size: 0x9C0

#endif
