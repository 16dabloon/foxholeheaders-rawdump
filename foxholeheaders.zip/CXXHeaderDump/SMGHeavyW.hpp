#ifndef UE4SS_SDK_SMGHeavyW_HPP
#define UE4SS_SDK_SMGHeavyW_HPP

class USMGHeavyW_C : public UHeavyMachineGunItemComponent
{
}; // Size: 0x9C0

#endif
