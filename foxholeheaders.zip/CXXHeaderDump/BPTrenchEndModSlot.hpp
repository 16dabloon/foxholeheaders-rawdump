#ifndef UE4SS_SDK_BPTrenchEndModSlot_HPP
#define UE4SS_SDK_BPTrenchEndModSlot_HPP

class UBPTrenchEndModSlot_C : public UModificationSlotComponent
{
}; // Size: 0x430

#endif
