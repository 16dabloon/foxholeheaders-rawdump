#ifndef UE4SS_SDK_FootprintRoadLeft_HPP
#define UE4SS_SDK_FootprintRoadLeft_HPP

class AFootprintRoadLeft_C : public ADecalActor
{
}; // Size: 0x220

#endif
