#ifndef UE4SS_SDK_BPFireDamageType_HPP
#define UE4SS_SDK_BPFireDamageType_HPP

class UBPFireDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
