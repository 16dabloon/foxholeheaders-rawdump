#ifndef UE4SS_SDK_SteamSockets_HPP
#define UE4SS_SDK_SteamSockets_HPP

class USteamSocketsNetConnection : public UNetConnection
{
}; // Size: 0x19D0

class USteamSocketsNetDriver : public UNetDriver
{
}; // Size: 0x718

#endif
