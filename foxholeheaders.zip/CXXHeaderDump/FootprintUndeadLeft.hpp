#ifndef UE4SS_SDK_FootprintUndeadLeft_HPP
#define UE4SS_SDK_FootprintUndeadLeft_HPP

class AFootprintUndeadLeft_C : public ADecalActor
{
}; // Size: 0x220

#endif
