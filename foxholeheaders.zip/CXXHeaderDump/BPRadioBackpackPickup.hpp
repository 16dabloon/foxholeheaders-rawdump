#ifndef UE4SS_SDK_BPRadioBackpackPickup_HPP
#define UE4SS_SDK_BPRadioBackpackPickup_HPP

class ABPRadioBackpackPickup_C : public ARadioBackpackPickup
{
}; // Size: 0x400

#endif
