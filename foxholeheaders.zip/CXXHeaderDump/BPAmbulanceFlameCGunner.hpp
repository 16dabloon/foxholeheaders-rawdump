#ifndef UE4SS_SDK_BPAmbulanceFlameCGunner_HPP
#define UE4SS_SDK_BPAmbulanceFlameCGunner_HPP

class UBPAmbulanceFlameCGunner_C : public UFlameMountComponent
{
}; // Size: 0x968

#endif
