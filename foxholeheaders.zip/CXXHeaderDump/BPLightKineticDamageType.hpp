#ifndef UE4SS_SDK_BPLightKineticDamageType_HPP
#define UE4SS_SDK_BPLightKineticDamageType_HPP

class UBPLightKineticDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
