#ifndef UE4SS_SDK_CoverFullStoneWall1eSnow_HPP
#define UE4SS_SDK_CoverFullStoneWall1eSnow_HPP

class ACoverFullStoneWall1eSnow_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0218 (size: 0x8)
    class UStaticMeshComponent* TrimStoneWall1;                                       // 0x0220 (size: 0x8)
    class UStaticMeshComponent* CoverFullStoneWall1;                                  // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
