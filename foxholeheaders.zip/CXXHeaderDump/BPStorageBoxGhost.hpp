#ifndef UE4SS_SDK_BPStorageBoxGhost_HPP
#define UE4SS_SDK_BPStorageBoxGhost_HPP

class ABPStorageBoxGhost_C : public ABuildGhost
{
    class UStaticMeshComponent* BoxMesh;                                              // 0x0580 (size: 0x8)

}; // Size: 0x588

#endif
