#ifndef UE4SS_SDK_ABP_LargeShipEngineW_CW0_HPP
#define UE4SS_SDK_ABP_LargeShipEngineW_CW0_HPP

class UABP_LargeShipEngineW_CW0_C : public UABP_LargeShipEngine0_C
{
}; // Size: 0x558

#endif
