#ifndef UE4SS_SDK_FootprintMudRight_HPP
#define UE4SS_SDK_FootprintMudRight_HPP

class AFootprintMudRight_C : public ADecalActor
{
}; // Size: 0x220

#endif
