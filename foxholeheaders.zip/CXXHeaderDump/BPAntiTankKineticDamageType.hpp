#ifndef UE4SS_SDK_BPAntiTankKineticDamageType_HPP
#define UE4SS_SDK_BPAntiTankKineticDamageType_HPP

class UBPAntiTankKineticDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
