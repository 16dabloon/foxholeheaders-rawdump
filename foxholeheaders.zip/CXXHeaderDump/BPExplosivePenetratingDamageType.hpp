#ifndef UE4SS_SDK_BPExplosivePenetratingDamageType_HPP
#define UE4SS_SDK_BPExplosivePenetratingDamageType_HPP

class UBPExplosivePenetratingDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
