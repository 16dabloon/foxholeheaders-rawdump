#ifndef UE4SS_SDK_CardboardBP02_HPP
#define UE4SS_SDK_CardboardBP02_HPP

class ACardboardBP02_C : public AActor
{
    class UBoxComponent* Box1;                                                        // 0x0218 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x0220 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0228 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0230 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0238 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent012;                               // 0x0240 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent010;                               // 0x0248 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent09;                                // 0x0250 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent08;                                // 0x0258 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent06;                                // 0x0260 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent05;                                // 0x0268 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent04;                                // 0x0270 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent03;                                // 0x0278 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent02;                                // 0x0280 (size: 0x8)
    class USceneComponent* SharedRoot;                                                // 0x0288 (size: 0x8)

}; // Size: 0x290

#endif
