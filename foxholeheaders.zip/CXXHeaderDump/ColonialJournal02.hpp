#ifndef UE4SS_SDK_ColonialJournal02_HPP
#define UE4SS_SDK_ColonialJournal02_HPP

class AColonialJournal02_C : public ALorePickup
{
}; // Size: 0x3F8

#endif
