#ifndef UE4SS_SDK_FootprintDirtLeft_HPP
#define UE4SS_SDK_FootprintDirtLeft_HPP

class AFootprintDirtLeft_C : public ADecalActor
{
}; // Size: 0x220

#endif
