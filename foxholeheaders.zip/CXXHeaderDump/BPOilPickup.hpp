#ifndef UE4SS_SDK_BPOilPickup_HPP
#define UE4SS_SDK_BPOilPickup_HPP

class ABPOilPickup_C : public AGearPickup
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x03F0 (size: 0x8)

}; // Size: 0x3F8

#endif
