#ifndef UE4SS_SDK_TownWLargeG1_HPP
#define UE4SS_SDK_TownWLargeG1_HPP

class ATownWLargeG1_C : public ATownWLargeGS1_C
{
}; // Size: 0xA60

#endif
