#ifndef UE4SS_SDK_BPVehicleProfileList_HPP
#define UE4SS_SDK_BPVehicleProfileList_HPP

class ABPVehicleProfileList_C : public AVehicleProfileList
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0268 (size: 0x8)

}; // Size: 0x270

#endif
