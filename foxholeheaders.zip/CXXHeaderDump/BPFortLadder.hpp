#ifndef UE4SS_SDK_BPFortLadder_HPP
#define UE4SS_SDK_BPFortLadder_HPP

class ABPFortLadder_C : public AReplicatedLadder
{
}; // Size: 0x250

#endif
