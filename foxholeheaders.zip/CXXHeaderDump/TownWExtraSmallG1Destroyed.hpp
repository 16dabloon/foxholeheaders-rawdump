#ifndef UE4SS_SDK_TownWExtraSmallG1Destroyed_HPP
#define UE4SS_SDK_TownWExtraSmallG1Destroyed_HPP

class ATownWExtraSmallG1Destroyed_C : public ADestroyedGarrisonHouse
{
    class URuinedMeshComponent* RuinedMesh7;                                          // 0x0638 (size: 0x8)
    class URuinedMeshComponent* RuinedMesh6;                                          // 0x0640 (size: 0x8)
    class URuinedMeshComponent* RuinedMesh5;                                          // 0x0648 (size: 0x8)
    class URuinedMeshComponent* RuinedMesh4;                                          // 0x0650 (size: 0x8)
    class URuinedMeshComponent* RuinedMesh3;                                          // 0x0658 (size: 0x8)
    class URuinedMeshComponent* RuinedMesh2;                                          // 0x0660 (size: 0x8)
    class URuinedMeshComponent* RuinedMesh1;                                          // 0x0668 (size: 0x8)
    class URuinedMeshComponent* RuinedMesh;                                           // 0x0670 (size: 0x8)
    class UDecalComponent* Decal;                                                     // 0x0678 (size: 0x8)
    class UBPStructureInteriorArea_C* BPStructureInteriorArea;                        // 0x0680 (size: 0x8)
    class UStaticMeshComponent* HouseMesh;                                            // 0x0688 (size: 0x8)

}; // Size: 0x690

#endif
