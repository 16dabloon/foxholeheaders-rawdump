#ifndef UE4SS_SDK_BPFacilityMineResource4Destroyed_HPP
#define UE4SS_SDK_BPFacilityMineResource4Destroyed_HPP

class ABPFacilityMineResource4Destroyed_C : public ADestroyedFacilityRefinery
{
    class UStaticMeshComponent* FacilityMineResource1BinDestroyed;                    // 0x06A0 (size: 0x8)
    class UStaticMeshComponent* MainMesh;                                             // 0x06A8 (size: 0x8)

}; // Size: 0x6B0

#endif
