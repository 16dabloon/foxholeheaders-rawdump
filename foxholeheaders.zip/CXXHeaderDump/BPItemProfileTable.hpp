#ifndef UE4SS_SDK_BPItemProfileTable_HPP
#define UE4SS_SDK_BPItemProfileTable_HPP

class ABPItemProfileTable_C : public AItemProfileTable
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0268 (size: 0x8)

}; // Size: 0x270

#endif
