#ifndef UE4SS_SDK_ShovelLore_HPP
#define UE4SS_SDK_ShovelLore_HPP

class AShovelLore_C : public ALorePickup
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x03F8 (size: 0x8)

}; // Size: 0x400

#endif
