#ifndef UE4SS_SDK_DiscordRichPresenceModule_HPP
#define UE4SS_SDK_DiscordRichPresenceModule_HPP

struct FDiscordRichPresenceData
{
}; // Size: 0x60

class UDiscordRichPresence : public UObject
{
}; // Size: 0x38

#endif
