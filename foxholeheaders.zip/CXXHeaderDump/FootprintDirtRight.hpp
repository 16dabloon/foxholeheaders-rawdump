#ifndef UE4SS_SDK_FootprintDirtRight_HPP
#define UE4SS_SDK_FootprintDirtRight_HPP

class AFootprintDirtRight_C : public ADecalActor
{
}; // Size: 0x220

#endif
