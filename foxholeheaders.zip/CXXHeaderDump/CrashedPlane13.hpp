#ifndef UE4SS_SDK_CrashedPlane13_HPP
#define UE4SS_SDK_CrashedPlane13_HPP

class ACrashedPlane13_C : public AActor
{
    class UStaticMeshComponent* StaticMeshComponent01;                                // 0x0218 (size: 0x8)
    class UStaticMeshComponent* StaticMeshComponent0;                                 // 0x0220 (size: 0x8)
    class UDecalComponent* NewDecalComponent6;                                        // 0x0228 (size: 0x8)
    class UDecalComponent* NewDecalComponent5;                                        // 0x0230 (size: 0x8)
    class UDecalComponent* NewDecalComponent4;                                        // 0x0238 (size: 0x8)
    class UDecalComponent* NewDecalComponent3;                                        // 0x0240 (size: 0x8)
    class UDecalComponent* NewDecalComponent2;                                        // 0x0248 (size: 0x8)
    class UDecalComponent* NewDecalComponent1;                                        // 0x0250 (size: 0x8)
    class UDecalComponent* NewDecalComponent;                                         // 0x0258 (size: 0x8)
    class USceneComponent* SharedRoot;                                                // 0x0260 (size: 0x8)

}; // Size: 0x268

#endif
