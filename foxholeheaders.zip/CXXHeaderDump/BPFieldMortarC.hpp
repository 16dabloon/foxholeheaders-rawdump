#ifndef UE4SS_SDK_BPFieldMortarC_HPP
#define UE4SS_SDK_BPFieldMortarC_HPP

class ABPFieldMortarC_C : public ABPFieldMortarBase_C
{
}; // Size: 0x1380

#endif
