#ifndef UE4SS_SDK_BPRifleShortWPickup_HPP
#define UE4SS_SDK_BPRifleShortWPickup_HPP

class ABPRifleShortWPickup_C : public AFirearmPickup
{
}; // Size: 0x3F0

#endif
