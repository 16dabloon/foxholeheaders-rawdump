#ifndef UE4SS_SDK_CoverHalfStoneWall1Snow_HPP
#define UE4SS_SDK_CoverHalfStoneWall1Snow_HPP

class ACoverHalfStoneWall1Snow_C : public AActor
{
    class UStaticMeshComponent* TrimStoneWall1;                                       // 0x0218 (size: 0x8)
    class UStaticMeshComponent* CoverHalfStoneWall1;                                  // 0x0220 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0228 (size: 0x8)

}; // Size: 0x230

#endif
