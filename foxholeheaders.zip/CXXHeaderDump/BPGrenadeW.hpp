#ifndef UE4SS_SDK_BPGrenadeW_HPP
#define UE4SS_SDK_BPGrenadeW_HPP

class ABPGrenadeW_C : public AGrenade_C
{
}; // Size: 0x3C0

#endif
