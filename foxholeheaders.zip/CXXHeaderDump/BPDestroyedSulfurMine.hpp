#ifndef UE4SS_SDK_BPDestroyedSulfurMine_HPP
#define UE4SS_SDK_BPDestroyedSulfurMine_HPP

class ABPDestroyedSulfurMine_C : public ADestroyedResourceMine
{
    class UStaticMeshComponent* StaticMesh7;                                          // 0x0628 (size: 0x8)
    class UStaticMeshComponent* StaticMesh6;                                          // 0x0630 (size: 0x8)
    class UStaticMeshComponent* StaticMesh5;                                          // 0x0638 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x0640 (size: 0x8)
    class UBoxComponent* NoBuildArea;                                                 // 0x0648 (size: 0x8)
    class UDecalComponent* Decal;                                                     // 0x0650 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0658 (size: 0x8)

}; // Size: 0x660

#endif
