#ifndef UE4SS_SDK_BPFacilityMineResource3_HPP
#define UE4SS_SDK_BPFacilityMineResource3_HPP

class ABPFacilityMineResource3_C : public ABPFacilityMineResource_C
{
    class UParticleSystemComponent* ProducingFX2;                                     // 0x0AC0 (size: 0x8)
    class UDecalComponent* Decal;                                                     // 0x0AC8 (size: 0x8)

}; // Size: 0xAD0

#endif
