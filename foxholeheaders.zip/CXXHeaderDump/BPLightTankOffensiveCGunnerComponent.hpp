#ifndef UE4SS_SDK_BPLightTankOffensiveCGunnerComponent_HPP
#define UE4SS_SDK_BPLightTankOffensiveCGunnerComponent_HPP

class UBPLightTankOffensiveCGunnerComponent_C : public UTankGunnerMountComponent
{
}; // Size: 0x8E0

#endif
