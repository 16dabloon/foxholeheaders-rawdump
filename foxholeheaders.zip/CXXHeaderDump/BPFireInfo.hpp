#ifndef UE4SS_SDK_BPFireInfo_HPP
#define UE4SS_SDK_BPFireInfo_HPP

class ABPFireInfo_C : public AFireInfo
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0280 (size: 0x8)

}; // Size: 0x288

#endif
