#ifndef UE4SS_SDK_BPVehicleMovementProfileList_HPP
#define UE4SS_SDK_BPVehicleMovementProfileList_HPP

class ABPVehicleMovementProfileList_C : public AVehicleMovementProfileList
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0268 (size: 0x8)

}; // Size: 0x270

#endif
