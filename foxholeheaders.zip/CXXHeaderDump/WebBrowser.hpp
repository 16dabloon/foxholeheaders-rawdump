#ifndef UE4SS_SDK_WebBrowser_HPP
#define UE4SS_SDK_WebBrowser_HPP

struct FWebJSCallbackBase
{
}; // Size: 0x20

struct FWebJSFunction : public FWebJSCallbackBase
{
}; // Size: 0x20

struct FWebJSResponse : public FWebJSCallbackBase
{
}; // Size: 0x20

#endif
