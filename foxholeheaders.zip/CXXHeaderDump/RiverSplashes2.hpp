#ifndef UE4SS_SDK_RiverSplashes2_HPP
#define UE4SS_SDK_RiverSplashes2_HPP

class ARiverSplashes2_C : public AEnvironmentVFX
{
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0228 (size: 0x8)

}; // Size: 0x230

#endif
