#ifndef UE4SS_SDK_BPFacilityPipeInsulated_HPP
#define UE4SS_SDK_BPFacilityPipeInsulated_HPP

class ABPFacilityPipeInsulated_C : public AModificationTemplate
{
    class UStaticMeshOverrideComponent* StaticMeshOverride;                           // 0x0218 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
