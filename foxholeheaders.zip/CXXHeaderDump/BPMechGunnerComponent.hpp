#ifndef UE4SS_SDK_BPMechGunnerComponent_HPP
#define UE4SS_SDK_BPMechGunnerComponent_HPP

class UBPMechGunnerComponent_C : public UTankGunnerMountComponent
{
}; // Size: 0x8E0

#endif
