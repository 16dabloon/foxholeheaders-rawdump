#ifndef UE4SS_SDK_BPFiremanMountComponent_HPP
#define UE4SS_SDK_BPFiremanMountComponent_HPP

class UBPFiremanMountComponent_C : public UFiremanMountComponent
{
}; // Size: 0x868

#endif
