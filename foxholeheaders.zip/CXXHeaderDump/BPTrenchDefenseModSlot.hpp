#ifndef UE4SS_SDK_BPTrenchDefenseModSlot_HPP
#define UE4SS_SDK_BPTrenchDefenseModSlot_HPP

class UBPTrenchDefenseModSlot_C : public UModificationSlotComponent
{
}; // Size: 0x430

#endif
