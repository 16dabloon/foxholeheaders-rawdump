#ifndef UE4SS_SDK_BPRPGTWPickup_HPP
#define UE4SS_SDK_BPRPGTWPickup_HPP

class ABPRPGTWPickup_C : public AGearPickup
{
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x03F0 (size: 0x8)

}; // Size: 0x3F8

#endif
