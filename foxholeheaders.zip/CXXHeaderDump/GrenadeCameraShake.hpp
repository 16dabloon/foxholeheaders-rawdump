#ifndef UE4SS_SDK_GrenadeCameraShake_HPP
#define UE4SS_SDK_GrenadeCameraShake_HPP

class UGrenadeCameraShake_C : public UCameraShake
{
}; // Size: 0x160

#endif
