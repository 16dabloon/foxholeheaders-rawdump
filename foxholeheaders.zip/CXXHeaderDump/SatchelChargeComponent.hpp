#ifndef UE4SS_SDK_SatchelChargeComponent_HPP
#define UE4SS_SDK_SatchelChargeComponent_HPP

class USatchelChargeComponent_C : public UExplosiveItemComponent
{
}; // Size: 0x928

#endif
