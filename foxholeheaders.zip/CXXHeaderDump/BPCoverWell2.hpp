#ifndef UE4SS_SDK_BPCoverWell2_HPP
#define UE4SS_SDK_BPCoverWell2_HPP

class ABPCoverWell2_C : public AActor
{
    class UWaterReloadSourceComponent* WaterReloadSource;                             // 0x0218 (size: 0x8)
    class UDecalComponent* Decal;                                                     // 0x0220 (size: 0x8)
    class UStaticMeshComponent* rope;                                                 // 0x0228 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0230 (size: 0x8)
    class USceneComponent* Scene;                                                     // 0x0238 (size: 0x8)

}; // Size: 0x240

#endif
