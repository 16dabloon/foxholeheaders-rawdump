#ifndef UE4SS_SDK_BPLoadingAreaBox_HPP
#define UE4SS_SDK_BPLoadingAreaBox_HPP

class UBPLoadingAreaBox_C : public ULoadingAreaBoxComponent
{
}; // Size: 0x410

#endif
