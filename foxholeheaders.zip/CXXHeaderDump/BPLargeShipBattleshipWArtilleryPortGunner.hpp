#ifndef UE4SS_SDK_BPLargeShipBattleshipWArtilleryPortGunner_HPP
#define UE4SS_SDK_BPLargeShipBattleshipWArtilleryPortGunner_HPP

class UBPLargeShipBattleshipWArtilleryPortGunner_C : public UArtilleryGunnerMountComponent
{
}; // Size: 0x920

#endif
