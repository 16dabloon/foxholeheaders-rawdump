#ifndef UE4SS_SDK_CoverFullStoneWall3e_HPP
#define UE4SS_SDK_CoverFullStoneWall3e_HPP

class ACoverFullStoneWall3e_C : public AActor
{
    class UStaticMeshComponent* Ivy15;                                                // 0x0218 (size: 0x8)
    class UStaticMeshComponent* Ivy08;                                                // 0x0220 (size: 0x8)
    class UStaticMeshComponent* Ivy13;                                                // 0x0228 (size: 0x8)
    class UStaticMeshComponent* CoverFullStoneWall3a;                                 // 0x0230 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0238 (size: 0x8)

}; // Size: 0x240

#endif
