#ifndef UE4SS_SDK_BPUniforms_HPP
#define UE4SS_SDK_BPUniforms_HPP

class UBPUniforms_C : public UUniforms
{
}; // Size: 0xBA8

#endif
