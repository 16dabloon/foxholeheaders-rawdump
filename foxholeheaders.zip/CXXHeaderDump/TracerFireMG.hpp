#ifndef UE4SS_SDK_TracerFireMG_HPP
#define UE4SS_SDK_TracerFireMG_HPP

class ATracerFireMG_C : public AWeaponFireFX
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
