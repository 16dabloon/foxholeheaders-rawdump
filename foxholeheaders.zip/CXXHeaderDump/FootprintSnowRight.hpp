#ifndef UE4SS_SDK_FootprintSnowRight_HPP
#define UE4SS_SDK_FootprintSnowRight_HPP

class AFootprintSnowRight_C : public ADecalActor
{
}; // Size: 0x220

#endif
