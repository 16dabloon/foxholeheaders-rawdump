#ifndef UE4SS_SDK_BPWarGameInstance_HPP
#define UE4SS_SDK_BPWarGameInstance_HPP

class UBPWarGameInstance_C : public UWarGameInstance
{
}; // Size: 0x1538

#endif
