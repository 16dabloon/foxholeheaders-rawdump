#ifndef UE4SS_SDK_BPSmokeDamageType_HPP
#define UE4SS_SDK_BPSmokeDamageType_HPP

class UBPSmokeDamageType_C : public UNonDamagingDamageType
{
}; // Size: 0x140

#endif
