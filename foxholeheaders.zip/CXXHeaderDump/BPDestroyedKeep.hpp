#ifndef UE4SS_SDK_BPDestroyedKeep_HPP
#define UE4SS_SDK_BPDestroyedKeep_HPP

class ABPDestroyedKeep_C : public ADestroyedKeep
{
    class UStaticMeshComponent* StaticMesh11;                                         // 0x0640 (size: 0x8)
    class UStaticMeshComponent* StaticMesh10;                                         // 0x0648 (size: 0x8)
    class UStaticMeshComponent* StaticMesh9;                                          // 0x0650 (size: 0x8)
    class UStaticMeshComponent* StaticMesh8;                                          // 0x0658 (size: 0x8)
    class UStaticMeshComponent* StaticMesh7;                                          // 0x0660 (size: 0x8)
    class UStaticMeshComponent* StaticMesh6;                                          // 0x0668 (size: 0x8)
    class UStaticMeshComponent* StaticMesh5;                                          // 0x0670 (size: 0x8)
    class UStaticMeshComponent* StaticMesh4;                                          // 0x0678 (size: 0x8)
    class UStaticMeshComponent* StaticMesh3;                                          // 0x0680 (size: 0x8)
    class UStaticMeshComponent* StaticMesh2;                                          // 0x0688 (size: 0x8)
    class UStaticMeshComponent* StaticMesh1;                                          // 0x0690 (size: 0x8)
    class UStaticMeshComponent* StaticMesh;                                           // 0x0698 (size: 0x8)
    class UBoxComponent* Box;                                                         // 0x06A0 (size: 0x8)
    class UStaticMeshComponent* Keep Mesh;                                            // 0x06A8 (size: 0x8)

}; // Size: 0x6B0

#endif
