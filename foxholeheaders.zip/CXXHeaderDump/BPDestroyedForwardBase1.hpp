#ifndef UE4SS_SDK_BPDestroyedForwardBase1_HPP
#define UE4SS_SDK_BPDestroyedForwardBase1_HPP

class ABPDestroyedForwardBase1_C : public ADestroyedBase
{
    class UDecalComponent* Decal;                                                     // 0x0650 (size: 0x8)
    class UDecalComponent* Decal3;                                                    // 0x0658 (size: 0x8)
    class UDecalComponent* Decal2;                                                    // 0x0660 (size: 0x8)
    class UDecalComponent* Decal1;                                                    // 0x0668 (size: 0x8)
    class UStaticMeshComponent* TownHallMesh;                                         // 0x0670 (size: 0x8)

}; // Size: 0x678

#endif
