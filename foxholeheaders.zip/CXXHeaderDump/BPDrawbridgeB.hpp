#ifndef UE4SS_SDK_BPDrawbridgeB_HPP
#define UE4SS_SDK_BPDrawbridgeB_HPP

class ABPDrawbridgeB_C : public ADrawbridge
{
    class UMultiplexedSkeletalMeshComponent* MultiplexedSkeletalMesh;                 // 0x0910 (size: 0x8)

}; // Size: 0x918

#endif
