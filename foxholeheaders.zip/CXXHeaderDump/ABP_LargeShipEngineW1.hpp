#ifndef UE4SS_SDK_ABP_LargeShipEngineW1_HPP
#define UE4SS_SDK_ABP_LargeShipEngineW1_HPP

class UABP_LargeShipEngineW1_C : public UABP_LargeShipEngine1_C
{
}; // Size: 0x558

#endif
