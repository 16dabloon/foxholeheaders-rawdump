#ifndef UE4SS_SDK_BPMotorcycleW_HPP
#define UE4SS_SDK_BPMotorcycleW_HPP

class ABPMotorcycleW_C : public ABPMotorcycleBaseW_C
{
}; // Size: 0x1340

#endif
