#ifndef UE4SS_SDK_BPStructureProfileList_HPP
#define UE4SS_SDK_BPStructureProfileList_HPP

class ABPStructureProfileList_C : public AStructureProfileList
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0268 (size: 0x8)

}; // Size: 0x270

#endif
