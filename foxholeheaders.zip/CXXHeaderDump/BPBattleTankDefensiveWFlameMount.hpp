#ifndef UE4SS_SDK_BPBattleTankDefensiveWFlameMount_HPP
#define UE4SS_SDK_BPBattleTankDefensiveWFlameMount_HPP

class UBPBattleTankDefensiveWFlameMount_C : public UBPFlameMountBaseComponent_C
{
}; // Size: 0x968

#endif
