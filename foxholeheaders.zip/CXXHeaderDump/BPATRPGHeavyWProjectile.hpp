#ifndef UE4SS_SDK_BPATRPGHeavyWProjectile_HPP
#define UE4SS_SDK_BPATRPGHeavyWProjectile_HPP

class ABPATRPGHeavyWProjectile_C : public AWarProjectile
{
    class UStaticMeshComponent* Mesh;                                                 // 0x0328 (size: 0x8)

}; // Size: 0x330

#endif
