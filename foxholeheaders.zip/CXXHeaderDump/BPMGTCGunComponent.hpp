#ifndef UE4SS_SDK_BPMGTCGunComponent_HPP
#define UE4SS_SDK_BPMGTCGunComponent_HPP

class UBPMGTCGunComponent_C : public UDeployableItemComponent
{
}; // Size: 0x8F8

#endif
