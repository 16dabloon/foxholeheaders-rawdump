#ifndef UE4SS_SDK_BPBattleTankOffensiveGunner_HPP
#define UE4SS_SDK_BPBattleTankOffensiveGunner_HPP

class UBPBattleTankOffensiveGunner_C : public UTankGunnerMountComponent
{
}; // Size: 0x8E0

#endif
