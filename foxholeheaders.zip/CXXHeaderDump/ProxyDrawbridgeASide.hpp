#ifndef UE4SS_SDK_ProxyDrawbridgeASide_HPP
#define UE4SS_SDK_ProxyDrawbridgeASide_HPP

class AProxyDrawbridgeASide_C : public AProxyDrawbridgeSide
{
}; // Size: 0x228

#endif
