#ifndef UE4SS_SDK_BPUnexplodedOrdnancePickup_HPP
#define UE4SS_SDK_BPUnexplodedOrdnancePickup_HPP

class ABPUnexplodedOrdnancePickup_C : public AGearPickup
{
}; // Size: 0x3F0

#endif
