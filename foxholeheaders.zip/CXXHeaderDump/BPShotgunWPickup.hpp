#ifndef UE4SS_SDK_BPShotgunWPickup_HPP
#define UE4SS_SDK_BPShotgunWPickup_HPP

class ABPShotgunWPickup_C : public AFirearmPickup
{
}; // Size: 0x3F0

#endif
