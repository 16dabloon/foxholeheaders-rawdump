#ifndef UE4SS_SDK_SnowTire_DUPL_1_HPP
#define UE4SS_SDK_SnowTire_DUPL_1_HPP

class ASnowTire_C : public ADecalActor
{
}; // Size: 0x220

#endif
