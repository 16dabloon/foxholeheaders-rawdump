enum class EMobileCSMQuality {
    NoFiltering = 0,
    PCF_1x1 = 1,
    PCF_2x2 = 2,
    EMobileCSMQuality_MAX = 3,
};

