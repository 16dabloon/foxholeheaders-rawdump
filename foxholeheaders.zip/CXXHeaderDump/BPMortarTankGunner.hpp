#ifndef UE4SS_SDK_BPMortarTankGunner_HPP
#define UE4SS_SDK_BPMortarTankGunner_HPP

class UBPMortarTankGunner_C : public UProjectileGunnerMountComponent
{
}; // Size: 0x8B8

#endif
