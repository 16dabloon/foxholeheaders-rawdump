#ifndef UE4SS_SDK_SledgeImpactEffect_HPP
#define UE4SS_SDK_SledgeImpactEffect_HPP

class ASledgeImpactEffect_C : public AImpactEffect
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0280 (size: 0x8)

}; // Size: 0x288

#endif
