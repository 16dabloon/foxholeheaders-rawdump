#ifndef UE4SS_SDK_BPMediumTankC_HPP
#define UE4SS_SDK_BPMediumTankC_HPP

class ABPMediumTankC_C : public ABPMediumTankBaseC_C
{
}; // Size: 0x1450

#endif
