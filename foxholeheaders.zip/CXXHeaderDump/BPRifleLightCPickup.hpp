#ifndef UE4SS_SDK_BPRifleLightCPickup_HPP
#define UE4SS_SDK_BPRifleLightCPickup_HPP

class ABPRifleLightCPickup_C : public AFirearmPickup
{
}; // Size: 0x3F0

#endif
