#ifndef UE4SS_SDK_BPTruckOffensiveGunnerComponent_HPP
#define UE4SS_SDK_BPTruckOffensiveGunnerComponent_HPP

class UBPTruckOffensiveGunnerComponent_C : public UBPLMGGunnerBase_C
{
}; // Size: 0x928

#endif
