#ifndef UE4SS_SDK_BPEmplacedMultiCGunner_HPP
#define UE4SS_SDK_BPEmplacedMultiCGunner_HPP

class UBPEmplacedMultiCGunner_C : public UArtilleryGunnerMountComponent
{
}; // Size: 0x920

#endif
