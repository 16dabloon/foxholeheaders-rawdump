#ifndef UE4SS_SDK_BPGlobalMovementModifiersInfo_HPP
#define UE4SS_SDK_BPGlobalMovementModifiersInfo_HPP

class ABPGlobalMovementModifiersInfo_C : public AGlobalMovementModifiersInfo
{
}; // Size: 0x238

#endif
