#ifndef UE4SS_SDK_BPHELaunchedGrenadePickup_HPP
#define UE4SS_SDK_BPHELaunchedGrenadePickup_HPP

class ABPHELaunchedGrenadePickup_C : public AGearPickup
{
}; // Size: 0x3F0

#endif
