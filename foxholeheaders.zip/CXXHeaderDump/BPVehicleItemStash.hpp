#ifndef UE4SS_SDK_BPVehicleItemStash_HPP
#define UE4SS_SDK_BPVehicleItemStash_HPP

class ABPVehicleItemStash_C : public AItemStash
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0860 (size: 0x8)

}; // Size: 0x868

#endif
