#ifndef UE4SS_SDK_TownRoadDecal5Long_HPP
#define UE4SS_SDK_TownRoadDecal5Long_HPP

class ATownRoadDecal5Long_C : public AActor
{
    class UDecalComponent* Decal2;                                                    // 0x0218 (size: 0x8)
    class UDecalComponent* Decal1;                                                    // 0x0220 (size: 0x8)
    class UDecalComponent* Decal;                                                     // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
