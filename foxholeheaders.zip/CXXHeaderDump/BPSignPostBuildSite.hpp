#ifndef UE4SS_SDK_BPSignPostBuildSite_HPP
#define UE4SS_SDK_BPSignPostBuildSite_HPP

class ABPSignPostBuildSite_C : public ASignPostBuildSite
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0800 (size: 0x8)

}; // Size: 0x808

#endif
