#ifndef UE4SS_SDK_BPBattleTankHeavyArtilleryGunnerWComponent_HPP
#define UE4SS_SDK_BPBattleTankHeavyArtilleryGunnerWComponent_HPP

class UBPBattleTankHeavyArtilleryGunnerWComponent_C : public UArtilleryGunnerMountComponent
{
}; // Size: 0x920

#endif
