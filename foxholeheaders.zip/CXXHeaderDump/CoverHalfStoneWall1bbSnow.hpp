#ifndef UE4SS_SDK_CoverHalfStoneWall1bbSnow_HPP
#define UE4SS_SDK_CoverHalfStoneWall1bbSnow_HPP

class ACoverHalfStoneWall1bbSnow_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0218 (size: 0x8)
    class UStaticMeshComponent* TrimStoneWall1;                                       // 0x0220 (size: 0x8)
    class UStaticMeshComponent* CoverHalfStoneWall1;                                  // 0x0228 (size: 0x8)
    class UStaticMeshComponent* PillarHalfStoneWall1;                                 // 0x0230 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0238 (size: 0x8)

}; // Size: 0x240

#endif
