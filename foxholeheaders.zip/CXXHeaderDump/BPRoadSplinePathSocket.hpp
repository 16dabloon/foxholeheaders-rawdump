#ifndef UE4SS_SDK_BPRoadSplinePathSocket_HPP
#define UE4SS_SDK_BPRoadSplinePathSocket_HPP

class UBPRoadSplinePathSocket_C : public UBuildSocketComponent
{
}; // Size: 0x2B0

#endif
