#ifndef UE4SS_SDK_RifleLongWComponent_HPP
#define UE4SS_SDK_RifleLongWComponent_HPP

class URifleLongWComponent_C : public UGrenadeAdapterComponent
{
}; // Size: 0xA50

#endif
