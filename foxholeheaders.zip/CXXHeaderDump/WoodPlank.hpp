#ifndef UE4SS_SDK_WoodPlank_HPP
#define UE4SS_SDK_WoodPlank_HPP

class AWoodPlank_C : public ADestructibleProp
{
    class UStaticMeshComponent* WoodOldPlankSquarev2;                                 // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
