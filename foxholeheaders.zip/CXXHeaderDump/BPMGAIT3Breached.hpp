#ifndef UE4SS_SDK_BPMGAIT3Breached_HPP
#define UE4SS_SDK_BPMGAIT3Breached_HPP

class ABPMGAIT3Breached_C : public ADestroyedFort
{
    class UTemplateComponent* FortCommonDestroyedDirtT3;                              // 0x0850 (size: 0x8)
    class ULocationMultiplexedMeshComponent* LocationMultiplexedMesh;                 // 0x0858 (size: 0x8)
    class UTemplateComponent* FortBreachedCommon;                                     // 0x0860 (size: 0x8)
    class UStaticMeshComponent* Floor;                                                // 0x0868 (size: 0x8)

}; // Size: 0x870

#endif
