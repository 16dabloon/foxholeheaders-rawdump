#ifndef UE4SS_SDK_BPIn06_HPP
#define UE4SS_SDK_BPIn06_HPP

class ABPIn06_C : public ABPLoreKeyStatueBase_C
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
