#ifndef UE4SS_SDK_BPRelicAPCMachineGunnerComponentRight_HPP
#define UE4SS_SDK_BPRelicAPCMachineGunnerComponentRight_HPP

class UBPRelicAPCMachineGunnerComponentRight_C : public UHitScanMountComponent
{
}; // Size: 0x928

#endif
