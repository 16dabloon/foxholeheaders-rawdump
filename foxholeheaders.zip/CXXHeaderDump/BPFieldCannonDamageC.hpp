#ifndef UE4SS_SDK_BPFieldCannonDamageC_HPP
#define UE4SS_SDK_BPFieldCannonDamageC_HPP

class ABPFieldCannonDamageC_C : public ABPFieldGunBase_C
{
}; // Size: 0x1320

#endif
