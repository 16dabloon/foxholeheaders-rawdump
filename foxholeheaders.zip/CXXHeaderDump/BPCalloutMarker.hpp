#ifndef UE4SS_SDK_BPCalloutMarker_HPP
#define UE4SS_SDK_BPCalloutMarker_HPP

class ABPCalloutMarker_C : public ACalloutMarker
{
    class USkeletalMeshComponent* PinPoint;                                           // 0x0238 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0240 (size: 0x8)

}; // Size: 0x248

#endif
