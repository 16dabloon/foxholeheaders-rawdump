#ifndef UE4SS_SDK_CoverFullStoneWall2d_DUPL_1_HPP
#define UE4SS_SDK_CoverFullStoneWall2d_DUPL_1_HPP

class ACoverFullStoneWall2d_C : public AActor
{
    class UStaticMeshComponent* CoverFullStoneWall2c;                                 // 0x0218 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
