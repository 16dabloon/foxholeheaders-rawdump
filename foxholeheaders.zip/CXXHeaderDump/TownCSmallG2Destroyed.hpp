#ifndef UE4SS_SDK_TownCSmallG2Destroyed_HPP
#define UE4SS_SDK_TownCSmallG2Destroyed_HPP

class ATownCSmallG2Destroyed_C : public ADestroyedGarrisonHouse
{
    class URuinedMeshComponent* RuinedMesh;                                           // 0x0638 (size: 0x8)
    class UStaticMeshComponent* HouseMesh;                                            // 0x0640 (size: 0x8)

}; // Size: 0x648

#endif
