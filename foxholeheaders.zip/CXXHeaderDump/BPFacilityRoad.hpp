#ifndef UE4SS_SDK_BPFacilityRoad_HPP
#define UE4SS_SDK_BPFacilityRoad_HPP

class ABPFacilityRoad_C : public ABuiltRoad
{
}; // Size: 0x840

#endif
