#ifndef UE4SS_SDK_BPAluminumPickup_HPP
#define UE4SS_SDK_BPAluminumPickup_HPP

class ABPAluminumPickup_C : public ABasicItemPickup
{
}; // Size: 0x3F0

#endif
