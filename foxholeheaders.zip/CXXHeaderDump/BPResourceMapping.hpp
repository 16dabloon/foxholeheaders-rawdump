#ifndef UE4SS_SDK_BPResourceMapping_HPP
#define UE4SS_SDK_BPResourceMapping_HPP

class UBPResourceMapping_C : public UResourceMapping
{
}; // Size: 0xD0

#endif
