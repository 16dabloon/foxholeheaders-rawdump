#ifndef UE4SS_SDK_BPFlameBackpackWPickup_HPP
#define UE4SS_SDK_BPFlameBackpackWPickup_HPP

class ABPFlameBackpackWPickup_C : public ABackpackItemPickup
{
}; // Size: 0x400

#endif
