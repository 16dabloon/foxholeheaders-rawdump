#ifndef UE4SS_SDK_BPOilComponent_HPP
#define UE4SS_SDK_BPOilComponent_HPP

class UBPOilComponent_C : public UFuelItemComponent
{
}; // Size: 0x920

#endif
