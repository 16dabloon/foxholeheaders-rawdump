#ifndef UE4SS_SDK_BPGrenadeWItemComponent_HPP
#define UE4SS_SDK_BPGrenadeWItemComponent_HPP

class UBPGrenadeWItemComponent_C : public UGrenadeItemComponent
{
}; // Size: 0x940

#endif
