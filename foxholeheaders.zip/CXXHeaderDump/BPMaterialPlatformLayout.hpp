#ifndef UE4SS_SDK_BPMaterialPlatformLayout_HPP
#define UE4SS_SDK_BPMaterialPlatformLayout_HPP

class UBPMaterialPlatformLayout_C : public UBPBaseResourceLayout_C
{
}; // Size: 0x88

#endif
