#ifndef UE4SS_SDK_RoadPathDecal5_HPP
#define UE4SS_SDK_RoadPathDecal5_HPP

class ARoadPathDecal5_C : public AActor
{
    class UDecalComponent* Decal;                                                     // 0x0218 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
