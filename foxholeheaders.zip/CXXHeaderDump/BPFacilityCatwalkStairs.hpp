#ifndef UE4SS_SDK_BPFacilityCatwalkStairs_HPP
#define UE4SS_SDK_BPFacilityCatwalkStairs_HPP

class ABPFacilityCatwalkStairs_C : public ACatWalk
{
    class UStaticMeshComponent* FacilityCatwalkRamp;                                  // 0x0840 (size: 0x8)
    class UBuildSocketComponent* FrontSocket;                                         // 0x0848 (size: 0x8)

}; // Size: 0x850

#endif
