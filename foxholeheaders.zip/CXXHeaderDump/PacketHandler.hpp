#ifndef UE4SS_SDK_PacketHandler_HPP
#define UE4SS_SDK_PacketHandler_HPP

class UHandlerComponentFactory : public UObject
{
}; // Size: 0x28

class UPacketHandlerProfileConfig : public UObject
{
    TArray<FString> Components;                                                       // 0x0028 (size: 0x10)

}; // Size: 0x38

#endif
