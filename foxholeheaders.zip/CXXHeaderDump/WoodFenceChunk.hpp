#ifndef UE4SS_SDK_WoodFenceChunk_HPP
#define UE4SS_SDK_WoodFenceChunk_HPP

class AWoodFenceChunk_C : public ADestructibleProp
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
