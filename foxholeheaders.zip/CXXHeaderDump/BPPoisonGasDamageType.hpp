#ifndef UE4SS_SDK_BPPoisonGasDamageType_HPP
#define UE4SS_SDK_BPPoisonGasDamageType_HPP

class UBPPoisonGasDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
