#ifndef UE4SS_SDK_BPDestroyedRVWallT1_HPP
#define UE4SS_SDK_BPDestroyedRVWallT1_HPP

class ABPDestroyedRVWallT1_C : public ADestroyedStructure
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0620 (size: 0x8)

}; // Size: 0x628

#endif
