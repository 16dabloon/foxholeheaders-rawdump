#ifndef UE4SS_SDK_BPBattleTankHeavyArtilleryEngineerWComponent_HPP
#define UE4SS_SDK_BPBattleTankHeavyArtilleryEngineerWComponent_HPP

class UBPBattleTankHeavyArtilleryEngineerWComponent_C : public UTankEngineerComponent
{
}; // Size: 0x888

#endif
