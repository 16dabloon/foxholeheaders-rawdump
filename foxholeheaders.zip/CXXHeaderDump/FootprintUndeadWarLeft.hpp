#ifndef UE4SS_SDK_FootprintUndeadWarLeft_HPP
#define UE4SS_SDK_FootprintUndeadWarLeft_HPP

class AFootprintUndeadWarLeft_C : public ADecalActor
{
}; // Size: 0x220

#endif
