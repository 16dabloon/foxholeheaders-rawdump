#ifndef UE4SS_SDK_Grenade_HPP
#define UE4SS_SDK_Grenade_HPP

class AGrenade_C : public ATimedProjectile
{
    class UStaticMeshComponent* GrenadeMesh;                                          // 0x03B8 (size: 0x8)

}; // Size: 0x3C0

#endif
