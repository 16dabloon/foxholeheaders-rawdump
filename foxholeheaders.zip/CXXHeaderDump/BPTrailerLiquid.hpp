#ifndef UE4SS_SDK_BPTrailerLiquid_HPP
#define UE4SS_SDK_BPTrailerLiquid_HPP

class ABPTrailerLiquid_C : public ABPTrailerStockpileBase_C
{
}; // Size: 0x12D0

#endif
