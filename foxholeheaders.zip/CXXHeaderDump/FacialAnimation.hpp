#ifndef UE4SS_SDK_FacialAnimation_HPP
#define UE4SS_SDK_FacialAnimation_HPP

class UAudioCurveSourceComponent : public UAudioComponent
{
    FName CurveSourceBindingName;                                                     // 0x0728 (size: 0x8)
    float CurveSyncOffset;                                                            // 0x0730 (size: 0x4)

}; // Size: 0x760

#endif
