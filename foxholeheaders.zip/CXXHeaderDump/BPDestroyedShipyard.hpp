#ifndef UE4SS_SDK_BPDestroyedShipyard_HPP
#define UE4SS_SDK_BPDestroyedShipyard_HPP

class ABPDestroyedShipyard_C : public ADestroyedVehicleFactory
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0640 (size: 0x8)

}; // Size: 0x648

#endif
