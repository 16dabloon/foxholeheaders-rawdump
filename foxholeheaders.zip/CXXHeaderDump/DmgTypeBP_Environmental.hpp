#ifndef UE4SS_SDK_DmgTypeBP_Environmental_HPP
#define UE4SS_SDK_DmgTypeBP_Environmental_HPP

class UDmgTypeBP_Environmental_C : public UDamageType
{
}; // Size: 0x40

#endif
