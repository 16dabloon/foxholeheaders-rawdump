#ifndef UE4SS_SDK_BPCalloutMarkerGhost_HPP
#define UE4SS_SDK_BPCalloutMarkerGhost_HPP

class ABPCalloutMarkerGhost_C : public ACalloutMarkerGhost
{
    class USkeletalMeshComponent* SkeletalMesh;                                       // 0x0228 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
