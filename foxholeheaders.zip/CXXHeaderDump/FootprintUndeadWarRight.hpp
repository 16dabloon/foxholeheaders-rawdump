#ifndef UE4SS_SDK_FootprintUndeadWarRight_HPP
#define UE4SS_SDK_FootprintUndeadWarRight_HPP

class AFootprintUndeadWarRight_C : public ADecalActor
{
}; // Size: 0x220

#endif
