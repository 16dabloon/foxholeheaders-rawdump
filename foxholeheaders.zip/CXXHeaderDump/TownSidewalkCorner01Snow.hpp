#ifndef UE4SS_SDK_TownSidewalkCorner01Snow_HPP
#define UE4SS_SDK_TownSidewalkCorner01Snow_HPP

class ATownSidewalkCorner01Snow_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0218 (size: 0x8)

}; // Size: 0x220

#endif
