#ifndef UE4SS_SDK_BPWoodPickup_HPP
#define UE4SS_SDK_BPWoodPickup_HPP

class ABPWoodPickup_C : public ABasicItemPickup
{
}; // Size: 0x3F0

#endif
