enum class ECameraFocusMethod {
    None = 0,
    Manual = 1,
    Tracking = 2,
    ECameraFocusMethod_MAX = 3,
};

