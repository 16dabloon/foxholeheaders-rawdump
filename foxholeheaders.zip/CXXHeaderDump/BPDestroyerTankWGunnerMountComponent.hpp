#ifndef UE4SS_SDK_BPDestroyerTankWGunnerMountComponent_HPP
#define UE4SS_SDK_BPDestroyerTankWGunnerMountComponent_HPP

class UBPDestroyerTankWGunnerMountComponent_C : public UTankGunnerMountComponent
{
}; // Size: 0x8E0

#endif
