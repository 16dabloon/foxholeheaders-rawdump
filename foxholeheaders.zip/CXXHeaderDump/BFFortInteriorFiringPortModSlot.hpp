#ifndef UE4SS_SDK_BFFortInteriorFiringPortModSlot_HPP
#define UE4SS_SDK_BFFortInteriorFiringPortModSlot_HPP

class UBFFortInteriorFiringPortModSlot_C : public UModificationSlotComponent
{
}; // Size: 0x430

#endif
