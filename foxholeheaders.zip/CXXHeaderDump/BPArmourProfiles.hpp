#ifndef UE4SS_SDK_BPArmourProfiles_HPP
#define UE4SS_SDK_BPArmourProfiles_HPP

class ABPArmourProfiles_C : public AArmourProfiles
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0378 (size: 0x8)

}; // Size: 0x380

#endif
