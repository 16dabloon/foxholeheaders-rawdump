#ifndef UE4SS_SDK_FencePost_DUPL_1_HPP
#define UE4SS_SDK_FencePost_DUPL_1_HPP

class AFencePost_C : public ADestructibleProp
{
    class UStaticMeshComponent* StaticMesh;                                           // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
