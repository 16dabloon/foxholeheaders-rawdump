enum class EEyeTrackerStatus {
    NotConnected = 0,
    NotTracking = 1,
    Tracking = 2,
    EEyeTrackerStatus_MAX = 3,
};

