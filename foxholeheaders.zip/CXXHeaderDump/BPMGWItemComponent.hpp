#ifndef UE4SS_SDK_BPMGWItemComponent_HPP
#define UE4SS_SDK_BPMGWItemComponent_HPP

class UBPMGWItemComponent_C : public UBPMGCItemComponent_C
{
}; // Size: 0x9C0

#endif
