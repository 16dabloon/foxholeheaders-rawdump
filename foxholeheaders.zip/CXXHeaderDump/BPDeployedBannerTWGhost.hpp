#ifndef UE4SS_SDK_BPDeployedBannerTWGhost_HPP
#define UE4SS_SDK_BPDeployedBannerTWGhost_HPP

class ABPDeployedBannerTWGhost_C : public ABPDeployedBannerTCGhost_C
{
}; // Size: 0x5A0

#endif
