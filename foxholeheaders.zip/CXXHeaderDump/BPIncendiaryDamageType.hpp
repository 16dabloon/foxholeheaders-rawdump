#ifndef UE4SS_SDK_BPIncendiaryDamageType_HPP
#define UE4SS_SDK_BPIncendiaryDamageType_HPP

class UBPIncendiaryDamageType_C : public USimDamageType
{
}; // Size: 0x140

#endif
