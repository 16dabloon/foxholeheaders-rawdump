#ifndef UE4SS_SDK_BPTrenchBridgeBuildFootprint_HPP
#define UE4SS_SDK_BPTrenchBridgeBuildFootprint_HPP

class ABPTrenchBridgeBuildFootprint_C : public AModificationTemplate
{
    class UBuildFootprintBoxComponent* BuildFootprintBox;                             // 0x0218 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
