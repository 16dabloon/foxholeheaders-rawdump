#ifndef UE4SS_SDK_BPLandscapeCullingRVTVolume_HPP
#define UE4SS_SDK_BPLandscapeCullingRVTVolume_HPP

class ABPLandscapeCullingRVTVolume_C : public ARuntimeVirtualTextureVolume
{
}; // Size: 0x220

#endif
