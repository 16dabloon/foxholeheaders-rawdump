#ifndef UE4SS_SDK_Puddle01_HPP
#define UE4SS_SDK_Puddle01_HPP

class APuddle01_C : public AActor
{
    class UDecalComponent* Decal;                                                     // 0x0218 (size: 0x8)
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)

}; // Size: 0x228

#endif
